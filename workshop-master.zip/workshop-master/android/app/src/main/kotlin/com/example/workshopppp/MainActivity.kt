package com.example.workshopppp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
